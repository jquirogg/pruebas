rootProject.name = "Selenium-Basic"

